package com.teampj.test.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PatientController {
	
	private static final Logger logger = LoggerFactory.getLogger(PatientController.class);

	// 스마트 캘린더 - 헬스케어
	@RequestMapping("calendar.pa")
	public String charts() {
		logger.info("url ==> calendar");
		
		return "pa/calendar";
	}
	
	// 예약 - 의사 선택
	@RequestMapping("appointment.pa")
	public String appointment() {
		logger.info("url ==> appointment");
		
		return "pa/appointment";
	}
	
	// 예약 - 예약일,시간선택
	@RequestMapping("appointment2.pa")
	public String appointment2() {
		logger.info("url ==> appointment2");
		
		return "pa/appointment2";
	}
	
	// 예약 - 진료과 선택
	@RequestMapping("appointment3.pa")
	public String appointment3() {
		logger.info("url ==> appointment3");
		
		return "pa/appointment3";
	}

	// 자가진단 - 정신 질환
	@RequestMapping("selfcheck.pa")
	public String selfcheck() {
		logger.info("url ==> selfcheck");
		
		return "pa/selfcheck";
	}
	
	// 자가진단 - 스트레스 자가진단
	@RequestMapping("selfcheck2.pa")
	public String selfcheck2() {
		logger.info("url ==> selfcheck2");
		
		return "pa/selfcheck2";
	}
	
	// 자가진단 - 감정인식
	@RequestMapping("selfcheck3.pa")
	public String selfcheck3() {
		logger.info("url ==> selfcheck3");
		
		return "pa/selfcheck3";
	}
	
	// 보건정보 - 약품정보 
	@RequestMapping("mediinfo.pa")
	public String mediinfo() {
		logger.info("url ==> mediinfo");
		
		return "pa/mediinfo";
	}
	
	// 보건정보 - 질병 정보
	@RequestMapping("mediinfo2.pa")
	public String mediinfo2() {
		logger.info("url ==> mediinfo2");
		
		return "pa/mediinfo2";
	}
	
	// 보건정보 - 식단정보
	@RequestMapping("mediinfo3.pa")
	public String mediinfo3() {
		logger.info("url ==> mediinfo3");
		
		return "pa/mediinfo3";
	}
	
	// 결제 - 하이패스 
	@RequestMapping("payment.pa")
	public String payment() {
		logger.info("url ==> payment");
		
		return "pa/payment";
	}
	
	// 결제 - 일반결제 
	@RequestMapping("payment2.pa")
	public String payment2() {
		logger.info("url ==> payment2");
		
		return "pa/payment2";
	}
	
}
