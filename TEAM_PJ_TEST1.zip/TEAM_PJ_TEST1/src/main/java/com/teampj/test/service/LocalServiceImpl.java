package com.teampj.test.service;

import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.teampj.test.persistence.LocalDAO;
import com.teampj.test.vo.AdminVO;
import com.teampj.test.vo.DoctorVO;
import com.teampj.test.vo.PatientVO;

@Service
public class LocalServiceImpl implements LocalService{

	@Autowired
	LocalDAO dao;
	
	@Autowired
	BCryptPasswordEncoder passwordEncoder;	// 비밀번호 암호화 객체
	
	@Override
	public void insertPatient(HttpServletRequest req, Model model) {
		PatientVO vo = new PatientVO();
		
		String patientID = req.getParameter("UserId");
		vo.setPatientID(patientID);
		String patientPW = req.getParameter("pwd");
		vo.setPatientPW(passwordEncoder.encode(patientPW));
		String patientName = req.getParameter("patientName");
		vo.setPatientName(patientName);
		String jumin1 = req.getParameter("jumin1");
		vo.setJumin1(jumin1);
		String jumin2 = req.getParameter("jumin2");
		vo.setJumin2(jumin2);
		String email = req.getParameter("email");
		vo.setEmail(email);
		// Email 인증
		// 인증 키 부분
		StringBuffer temp = new StringBuffer();
		Random rnd = new Random();
		for(int i=0;i<6;i++) {
			int rIndex = rnd.nextInt(2);
			switch(rIndex) {
			case 0:
				temp.append((char)((int)(rnd.nextInt(26))+65));
				break;
			case 1:
				temp.append((rnd.nextInt(10)));
				break;
			}
		}
		String key = temp.toString();
		
		vo.setKey(key);
		
		int insertCnt = dao.insertPatient(vo);

		System.out.println(insertCnt);
		if(insertCnt != 0) {
			dao.sendMail(email, key);
		}
		model.addAttribute("insertCnt", insertCnt);
	}
	
	@Override
	public void insertDoctor(HttpServletRequest req, Model model) {
		DoctorVO vo = new DoctorVO();
		
		String doctorID = req.getParameter("doctorID");
		vo.setDoctorID(doctorID);
		String doctorPW = req.getParameter("doctorPW");
		vo.setDoctorPW(passwordEncoder.encode(doctorPW));
		String doctorName = req.getParameter("doctorName");
		vo.setDoctorName(doctorName);
		String email = req.getParameter("email");
		vo.setEmail(email);
		String licence = req.getParameter("licence");
		vo.setLicence(licence);
		String tel = req.getParameter("tel");
		vo.setTel(tel);

		int insertCnt = dao.insertDoctor(vo);

		System.out.println(insertCnt);
	
		model.addAttribute("insertCnt", insertCnt);
	}
	
	@Override
	public void insertAdmin(HttpServletRequest req, Model model) {
		AdminVO vo = new AdminVO();
		
		String AdminID = req.getParameter("UserId");
		vo.setAdminID(AdminID);
		String AdminPW = req.getParameter("pwd");
		vo.setAdminPW(passwordEncoder.encode(AdminPW));
		
		int insertCnt = dao.insertAdmin(vo);
		System.out.println(insertCnt);
		model.addAttribute("insertCnt", insertCnt);
	}
	
	
	@Override
	public void searchPatients(HttpServletRequest req, Model model) {
		String keyword = req.getParameter("keyword");
		System.out.println(keyword);
		List<PatientVO> list = dao.selectPatientList(keyword);
		
		model.addAttribute("dtos",list);
	}

	@Override
	public void emailChk(HttpServletRequest req, Model model) {
		String key = req.getParameter("key");
		
		int updateCnt = dao.updatePatientEnabled(key);

		model.addAttribute("updateCnt",updateCnt);
	}

	

}
