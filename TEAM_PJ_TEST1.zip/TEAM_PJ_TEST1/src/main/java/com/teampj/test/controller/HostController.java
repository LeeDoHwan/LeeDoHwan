package com.teampj.test.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class HostController {

	private static final Logger logger = LoggerFactory.getLogger(HostController.class);
	
    // 호스트
	
	// - 회원 관리 -
	// 의료인 회원가입 승인
	@RequestMapping("/signcheck.ho")
	public String signcheck() {
		logger.info("url ==> /signcheck.ho");
		
		return "ho/signcheck";
	}
	
	// 회원조회
	@RequestMapping("/select.ho")
	public String select() {
		logger.info("url ==> /select.ho");
		
		return "ho/select";
	}
	// - 회원 관리 종료 -
	
	// - 물품관리 - 
	// 약품관리
	@RequestMapping("/drugregi.ho")
	public String drugregi() {
		logger.info("url ==> /drugregi.ho");
		
		return "ho/drugregi";
	}
	
	// 의료용품 관리
	@RequestMapping("/medicalsup.ho")
	public String medicalsup() {
		logger.info("url ==> /medicalsup.ho");
		
		return "ho/medicalsup";
	}
	// - 물품관리 종료 - 
	
	// - 보건정보 - 
	// 약품정보
	@RequestMapping("/druginfo.ho")
	public String druginfo() {
		logger.info("url ==> /druginfo.ho");
		
		return "ho/druginfo";
	}
	
	// 질병정보
	@RequestMapping("/illnessinfo.ho")
	public String illnessinfo() {
		logger.info("url ==> /illnessinfo.ho");
		
		return "ho/illnessinfo";
	}
	
	// 식단정보
	@RequestMapping("/dietinfo.ho")
	public String dietinfo() {
		logger.info("url ==> /dietinfo.ho");
		
		return "ho/dietinfo";
	}
	// - 보건정보 종료 -
	
	// 결산
	@RequestMapping("/total.ho")
	public String total() {
		logger.info("url ==> /total.ho");
		
		return "ho/total";
	}
	
	// 챗봇 
	@RequestMapping("/chatbot.ho")
	public String chatbot() {
		logger.info("url ==> /chatbot.ho");
		
		return "ho/chatbot";
	}
	// 통계
	@RequestMapping("/statistics.ho")
	public String statistics() {
		logger.info("url ==> /statistics.ho");
		
		return "ho/statistics";
	}
	
	// 병실배정 페이지
	@RequestMapping("/assign.ho")
	public String assign() {
		logger.info("url ==> assign");
		
		return "ho/assign";
	}
	
	
	@RequestMapping("/floating.ho")
	public String floating() {
		logger.info("url ==> /floating.ho");
		
		return "ho/floating";
	}
	
	@RequestMapping("/illstats.ho")
	public String illstats() {
		logger.info("url ==> /illstats.ho");
		
		return "ho/illstats";
	}
	
	@RequestMapping("/stats.ho")
	public String stats() {
		logger.info("url ==> /stats.ho");
		
		return "ho/stats";
	}
	
	// 원래 템플릿 샘플이 궁금하시면 sample 입력해보세용...! 
	@RequestMapping("/sample.ho")
	public String sample() {
		logger.info("url ==> /sample.ho");
		
		return "sample";
	}
	
	
}
