package com.teampj.test.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DoctorController {
	
	private static final Logger logger = LoggerFactory.getLogger(DoctorController.class);
	
	// 의사	
	
	// 진료 - 진단 
	@RequestMapping("diagnosis.dr")
	public String diagnosis() {
		logger.info("url ==> diagnosis");
		
		return "dr/diagnosis";
	}
	
	// 진료 - 검사
	@RequestMapping("prescription.dr")
	public String prescription() {
		logger.info("url ==> prescription");
		
		return "dr/prescription";
	}
	
	// 처방 - 입원여부 작성
	@RequestMapping("register.dr")
	public String register() {
		logger.info("url ==> register");
		
		return "dr/register";
	}
	
	// 처방 - 치료방법
	@RequestMapping("treatment.dr")
	public String treatment() {
		logger.info("url ==> treatment");
		
		return "dr/treatment";
	}
	
	// 처방 - 처방전 작성
	@RequestMapping("treatmentreceipt.dr")
	public String treatmentreceipt() {
		logger.info("url ==> treatmentreceipt");
		
		return "dr/treatmentreceipt";
	}
	
	// 스케줄 관리 
	@RequestMapping("schedule.dr")
	public String schedule() {
		logger.info("url ==> schedule");
		
		return "dr/schedule";
	}
	
	// 환자관리 - 환자 조회 
	@RequestMapping("patientinfo.dr")
	public String patientinfo() {
		logger.info("url ==> patientinfo");
		
		return "dr/patientinfo";
	}
	

}
