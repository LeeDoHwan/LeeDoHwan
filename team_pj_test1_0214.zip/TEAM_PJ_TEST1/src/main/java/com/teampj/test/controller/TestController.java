package com.teampj.test.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class TestController {

	private static final Logger logger = LoggerFactory.getLogger(TestController.class);
	
	
	@RequestMapping("index")
	public String index() {
		logger.info("url ==> index");
		
		return "index";
	}
	
	@RequestMapping("login")
	public String login() {
		logger.info("url ==> login");
		
		return "login";
	}
	
	@RequestMapping("index2")
	public String index2() {
		logger.info("url ==> index2");
		
		return "index2";
	}
	
	@RequestMapping("calendar")
	public String charts() {
		logger.info("url ==> calendar");
		
		return "calendar";
	}
	
	// 원래 템플릿 샘플이 궁금하시면 sample 입력해보세용...! 
	@RequestMapping("sample")
	public String sample() {
		logger.info("url ==> sample");
		
		return "sample";
	}
	
	
}
